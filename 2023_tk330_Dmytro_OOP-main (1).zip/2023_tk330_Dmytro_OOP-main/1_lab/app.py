from datetime import datetime
name = "Dmytro"
location = "Lviv"

print(f"{name} start programming at {datetime.now()}. {location} is the best city!")
